-- Criar o banco de dados

-- Escolher entre os BDs existentes qual será utilizado

-- Criar a tabela livros

-- Criar a tabela categorias

-- Criar o relacionamento entre as tabelas livros e categorias
-- 1. Adicionando a chave estrangeira na tabela livros
-- 2. informando que a chave primaria relacionada está na tabela categorias
-- Assim: Um livro TEM uma categoria || Uma categoria PODE TER de 0 a n livros
